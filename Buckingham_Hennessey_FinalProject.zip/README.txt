Hennessey_Kevin.zip Files:
- index.html: Main Html webpage.
- node_graph.js: Javascript file containing all code to interactable force directed graph
- nodes.json: JSON file which contains the information pertaining to nodes such as source target and value. 
- Assignment5_pt1.pdf: PDF file which contains 4 designs, and details the pros and cons of 2 visualizations for part 1 of this assignment.

Instructions: 
- Download and unzip .zip file.
- Create server on local machine using command: python -m http.server 10088
	- Ensure this server is created in same directory in which all files are located.
- Access local server. Paste 'localhost:10088' into Chrome or browser of choice.
- Thank You!  